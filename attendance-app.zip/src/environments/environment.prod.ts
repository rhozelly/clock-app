export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCXpLlbw_nTqyakjqafjdsRnFxdocQrbQQ",
    authDomain: "attendance-app-92cbe.firebaseapp.com",
    projectId: "attendance-app-92cbe",
    storageBucket: "attendance-app-92cbe.appspot.com",
    messagingSenderId: "900418340819",
    appId: "1:900418340819:web:ac0fe5f6b36dc5b92f5126"
  }
};
