// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyCXpLlbw_nTqyakjqafjdsRnFxdocQrbQQ",
    authDomain: "attendance-app-92cbe.firebaseapp.com",
    projectId: "attendance-app-92cbe",
    storageBucket: "attendance-app-92cbe.appspot.com",
    messagingSenderId: "900418340819",
    appId: "1:900418340819:web:ac0fe5f6b36dc5b92f5126"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
