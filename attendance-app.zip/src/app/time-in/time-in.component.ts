import { Component, OnInit } from '@angular/core';
import {TimesheetsDialogComponent} from "../timesheets/timesheets-dialog/timesheets-dialog.component";

@Component({
  selector: 'app-time-in',
  templateUrl: './time-in.component.html',
  styleUrls: ['./time-in.component.css']
})
export class TimeInComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
