module.exports = {
  node: {
    path: true,
    crypto: true,
    fs: 'empty'
  }
}
